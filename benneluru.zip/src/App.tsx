import './App.css'
import Footer from './components/Footer'
import IndexPage from './pages'

export default function App() {
  return <>
    <IndexPage />
    <Footer />
  </>
}

